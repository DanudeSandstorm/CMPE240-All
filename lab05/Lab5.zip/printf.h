#ifndef PRINTF_H
#define PRINTF_H

int printf(const char *format, ...);

int sprintf(char *out, const char *format, ...);

#endif // PRINTF_H
